-- Your SQL goes here
ALTER TABLE stock
RENAME COLUMN stocks TO stocks_id;
