-- This file should undo anything in `up.sql`
ALTER TABLE stocks
ALTER COLUMN product_id TYPE INTEGER;;
